# Project Title

Title of your project goes here

## Project Description

Describe what is the aim of your project and what problem it solves

### Prerequisites

What things you need to install the software and how to install them

```
Give examples
```

### Installation

A step by step series of examples that tell you how to get a development env running

Say what the step will be

```
Give the example
```

And repeat

```
until finished
```

## Running the demo

Explain how to run the demo

```
Give an example
```

## Deployment

Add additional notes about how to deploy this on a system or in cloud

## Authors

* **Prateek Gupta** - *Sample Template* - [dsbyprateekg](https://github.com/dsbyprateekg)